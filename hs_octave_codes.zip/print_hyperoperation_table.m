function print_hyperoperation_table(H, table_data)
    % PRINT_HYPEROPERATION_TABLE - Displays the hyperoperation table with improved alignment

    % Determine number of columns
    n = length(H);

    % Initialize column width based on header length
    col_widths = zeros(1, n);
    for j = 1:n
        col_widths(j) = length(H{j});
    end

    % Loop through data to find the max width of each column
    for i = 1:n
        for j = 1:n
            current_cell = table_data{i,j};
            if isempty(current_cell)
                set_str = '{}';
            else
                if ~iscell(current_cell)
                    current_cell = {current_cell};
                end
                str_elements = cellfun(@(x) convert_to_str(x), current_cell, 'UniformOutput', false);
                set_str = sprintf('{%s}', strjoin(str_elements, ','));
            end
            col_widths(j) = max(col_widths(j), length(set_str));
        end
    end

    % Print header
    fprintf('%-*s |', max(cellfun(@length, H)), '*');
    for j = 1:n
        fprintf('%-*s ', col_widths(j), H{j});
    end
    fprintf('\n');

    % Print rows
    for i = 1:n
        fprintf('%-*s |', max(cellfun(@length, H)), H{i});
        for j = 1:n
            current_cell = table_data{i,j};
            if isempty(current_cell)
                set_str = '{}';
            else
                if ~iscell(current_cell)
                    current_cell = {current_cell};
                end
                str_elements = cellfun(@(x) convert_to_str(x), current_cell, 'UniformOutput', false);
                set_str = sprintf('{%s}', strjoin(str_elements, ','));
            end
            fprintf('%-*s ', col_widths(j), set_str);
        end
        fprintf('\n');
    end
end

function s = convert_to_str(elem)
    if isnumeric(elem)
        s = num2str(elem);
    elseif islogical(elem)
        s = mat2str(elem);
    elseif ischar(elem) || isstring(elem)
        s = char(elem); % Convert string to char array
    else
        s = '?';
    end
end
