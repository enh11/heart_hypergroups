function result = hyperoperation(H, M, x, y)
% HYPEROPERATION Get operation result from hyperoperation table
%
% Inputs:
% H - Cell array of element labels (e.g., {’a’,’b’,’c’,’d’})
% M - Hyperoperation table (cell array)
% x - First element (e.g., ’a’)
% y - Second element (e.g., ’b’)
%
% Output:
% result - Corresponding operation result from M (e.g., {’a’,’b’})
% Find indices of x and y in H
i = find(strcmp(H, x));
j = find(strcmp(H, y));
% Verify elements exist
if i*j==0
error('Input elements not found in H');
end
% Return result from M
result =  M{i, j};
end